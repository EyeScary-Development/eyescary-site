#ESDSyntax v0.1.1.

import sys
RED = '\033[38;5;203m'
ORANGE = '\033[38;5;208m'
GREEN = '\033[38;5;120m'
YELLOW = '\033[38;5;226m'
BLUE = '\033[38;5;117m' #dark-aqua sort of colour
BLUE2 = '\033[96m' #darker blue
RESET = '\033[0m'


def producesyntaxed(text, color, useSpace=True):
    try:
        if useSpace:
            sys.stdout.write(color + text + RESET + ' ')
        else:
            sys.stdout.write(color + text + RESET)
    except:
        print(text)

def canfloat(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

def colourElse(part, words):
    if len(words) != 1:
        producesyntaxed(part, RED)
    else:
        producesyntaxed(part, BLUE)

def colourIf(part, words):
    if len(words) == 4:
        producesyntaxed(part, BLUE)
    else:
        producesyntaxed(part, RED)

#Colour write or input
def colourWI(part, words):
    if len(words) > 1 and len(part) == 5:
        producesyntaxed(part, BLUE)
    else:
        producesyntaxed(part, YELLOW)

#Colour normal BLUE/RED stuff
def colour(part, words, correctLength, correctLineLength=1):
    if len(words) >= correctLineLength and len(part) == correctLength:
        producesyntaxed(part, BLUE)
    else:
        producesyntaxed(part, RED)

def syntax(filext, lnnum, line):
    match filext:
        case "esdla":
            print(f"\n{lnnum} :", end=" ")
            words = line.split()
            for part in words:
                match part:
                    case _ if canfloat(part) == True:
                        producesyntaxed(part, ORANGE)
                    case "write" | "input":
                        colourWI(part, words)
                    case _ if part.startswith("if"):
                        colourIf(part, words)
                    case _ if part.startswith("else"):
                        colourElse(part, words)
                    case "endstat":
                        colour(part, words, 7, 1)
                    case "var":
                        colour(part, words, 3, 3)
                    case _:
                        producesyntaxed(part, GREEN)
        case _:
            print("\n", lnnum, ":", line)

if __name__ == "__main__": print("you're not meant to run this directly, stop it!")