import random
variablenames=[]
variablevals=[]

def radno():
    toprint=varval[7:]
    bound1=float(toprint[:1])
    bound2=float(toprint[2:])
    return random.randint(bound1,bound2)
def vars():
    overtmod=0
    global varval
    varname=input("what would you like the variable to be named? (this won't matter too much later): ")
    if varname in variablenames:
       print("error, variable already created, overwrite?")
       usin=input("y/n: ")
       if usin=="y":
          fetch=variablenames.index(varname)
          variablenames.remove(varname)
          variablenames.insert(fetch, varname)
          overtmod=1
    else:
        variablenames.append(varname)
    if overtmod==1:
        fetch=variablenames.index(varname)
        varval=input("input a floating or integer value (radnom in beta, cannot use digits over 9): ")
        if varval.startswith("radnom"):
            varval=radno()
        variablevals.pop(fetch)
        variablevals.insert(fetch, float(varval))
    else:
       varval=input("input a floating or integer value (radnom in beta, cannot use digits over 9): ")
       if varval.startswith("radnom"):
           varval=radno()
       variablevals.append(float(varval))
    varloc=variablenames.index(varname)
    print("the name of the variable you can use to call through getvar only is ", varloc, " it's value at present is, ", varval)
    overtmod=0
def getvars():
   toindex=int(input("input the predispensed variable number you want to access: "))
   print("that variable is called ", variablenames[toindex], ", it's value is ", variablevals[toindex])
def printah():
    toprint=usin[6:]
    compo = toprint.split()
    compo = [part.replace(" ", "") for part in compo]
    for part in compo:
     if part in variablenames:
        varname=part
        fetch=variablenames.index(varname)
        print(variablevals[fetch], end=" ")
     else:
            print(part, end=" ")
    print()
print("wearlang test shell")

loop = 250
while loop >= 0:
    usin=input("line by line code or access varcreate here: ")
    if usin == "var":
     vars()
    elif usin == "quit":
       exit()
    elif usin == "getvar":
       getvars()
    elif usin.startswith("write"):
       printah()
    loop -= 1
print("looks like your test run is up! Thank you for experiencing a high level programming language programmed in a high level programming language!")