import sys
global RED
global GREEN
global YELLOW
global BLUE
global RESET
RED = '\033[38;5;203m'
ORANGE = '\033[38;5;208m'
GREEN = '\033[38;5;120m'
YELLOW = '\033[38;5;226m'
BLUE = '\033[38;5;117m'
RESET = '\033[0m'


def producesyntaxed(text, color):
    sys.stdout.write(color + text + RESET + ' ')

def canfloat(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

def syntax(filext, lnnum, line):
    print(lnnum, ":", end=" ")
    if filext == ".esdla":
        words = line.split()  # Split the line into words
        for part in words:
            if canfloat(part) == True:
                producesyntaxed(part, ORANGE)
            elif part == "write":
                if len(words) > 1:
                    producesyntaxed(part, BLUE)
                else:
                    producesyntaxed(part, YELLOW)
            elif part == "input":
                if len(words) > 1:
                    producesyntaxed(part, BLUE)
                else:
                    producesyntaxed(part, YELLOW)
            elif part.startswith("if"):
                if len(words) == 4:
                    producesyntaxed(part, BLUE)
                else:
                    producesyntaxed(part, RED)
            elif part.startswith("else"):
                if part[4:] == ":":
                    producesyntaxed(part, RED)
                else:
                    producesyntaxed(part, BLUE)
            elif part == "endstat":
                producesyntaxed(part, BLUE)
            elif part == "var":
                if len(words) == 1:
                    producesyntaxed(part, BLUE)
                else:
                    producesyntaxed(part, RED)
            elif part == "num" or part == "str":
                if len(words) == 1:
                    producesyntaxed(part, BLUE)
                else:
                    producesyntaxed(part, RED)
            else:
                producesyntaxed(part, GREEN)
