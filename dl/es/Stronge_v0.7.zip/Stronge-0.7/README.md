closed source beta versions of Stronge, current versions (to all intents and purposes open source) found on https://eyescary.pages.dev/stronge
