import ESDLang
import sys
from esdlals import esdlaserv
import re
print("welcome to stronge editor v0.6")
global filnam
global file
global linenum
linenum=1
filnam=input("choose a  filename: ")
filext=input("choose file type: ")
if filext=="" or filext == "\n" or filext == " \n":
    filnam+=".txt"
else:
    filnam+=filext
file=open(filnam, 'a+')
loop=300
while loop >= 0:
    print()
    loop-=1


def newlntoolbe4(string):
    global file
    splitted=string.split()
    goto=splitted[1]
    goto=int(goto[1:])
    file.seek(0)
    lines = file.readlines()
    file.seek(0)
    if goto + 1 < len(lines):
        origcont=lines[goto-1]
        lines[goto-1] = '\n' + origcont
    file.close()
    clr()
    file = open(filnam, 'a+')
    file.seek(0)
    file.writelines(lines)
    lop=300
    while lop>0:
        print()
        lop-=1
    file.close()
    file=open(filnam,'a+')
    refre()
    splitted.pop(1)
    splitted.insert(1, str(goto))
    toins=' '.join(splitted)
    inserttool(toins)


def newlntool(string):
    global file
    file.close()
    file = open(filnam, 'a+')
    file.seek(0)
    lines = file.readlines()
    file.seek(0)
    splitted=string.split()
    togo=int(splitted[1])
    if 1 <= togo <= len(lines):
        lines[togo - 1] += "\n"
    file.close()
    clr()
    file = open(filnam, 'a+')
    file.writelines(lines)
    lop=300
    while lop>0:
        print()
        lop-=1
    file.close()
    file=open(filnam,'a+')
    refre()
    splitted.pop(1)
    togo+=1
    splitted.insert(1, str(togo))
    toins=' '.join(splitted)
    inserttool(toins)
def refre():
    linenum=1
    file.seek(0)
    for line in file:
        print(linenum, ":", line.strip())
        linenum += 1
    global newlinnum
    newlinnum=linenum
def clr():
    file = open(filnam, 'w')
    file.write("")
    file.close()
def inserttool(string):
    global file
    file.close()
    file = open(filnam, 'a+')
    file.seek(0)
    lines = file.readlines()
    file.seek(0)
    splitted=string.split()
    togo=int(splitted[1])
    if 1 <= togo <= len(lines):
        toprint = input(":: ".format(togo))
        lines[togo - 1] = toprint + '\n'
    file.close()
    clr()
    file = open(filnam, 'a+')
    file.writelines(lines)
    lop=300
    while lop>0:
        print()
        lop-=1
    file.close()
    file=open(filnam,'a+')
    refre()

def deletelinetool(string):
    global file
    split=string.split()
    goto=int(split[1])
    file.seek(0)
    lines=file.readlines()
    if 1 <= goto <= len(lines):
        lines.pop(goto-1)
    file.close()
    clr()
    file = open(filnam, 'a+')
    file.writelines(lines)
    lop=300
    while lop>0:
        print()
        lop-=1
    file.close()
    file=open(filnam,'a+')
    refre()
file.seek(0)
for line in file:
    print(linenum, ":", line.strip())
    linenum+=1
loop = 2000
while loop > 0:
    print(linenum, end=' ')
    toprint=input(": ")
    if toprint == "savex":
        print("saving...")
        file.close()
        exit()
    elif toprint == "savrun":
        print("saving...")
        file.close()
        import ESDLang
        break
    elif toprint == "filclr":
        file.close()
        clr()
        file = open(filnam, 'a+')
        print("started afresh \n")
        linenum=1
    elif toprint.startswith("ins"):
        inserttool(toprint)
        linenum=newlinnum
    elif toprint.startswith("newln"):
        if toprint.split()[1].startswith(":"):
            newlntoolbe4(toprint)
            linenum+=1
        else:
            newlntool(toprint)
            linenum+=1
    elif toprint.startswith("delln"):
        deletelinetool(toprint)
        linenum=newlinnum
    else:
        if filext == ".esdla":
            cont=toprint
            toprint=esdlaserv(toprint)
            file.write(str(toprint)+"\n")
            re=300
            while re >0:
                print()
                re-=1
            refre()
            linenum=newlinnum
        else:
            file.write(str(toprint)+"\n")
            re=300
            while re >0:
                print()
                re-=1
            refre()
            linenum=newlinnum
