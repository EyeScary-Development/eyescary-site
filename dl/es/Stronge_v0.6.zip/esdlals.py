def esdlaserv(string):
    global file
    from stronge import linenum
    from stronge import refre
    from stronge import clr
    from stronge import filnam
    if string.startswith("w"):
        if len(string)==1:
            string="write"
            goto=linenum
            toadd=input(":: ")
            string = "write " + toadd
    elif string.startswith("v"):
        if len(string)==1:
            string="var"
    elif string.startswith("s"):
        if len(string) == 1:
            string="str"
    elif string.startswith("e"):
        if len(string) == 1:
            string="else"
        elif string.startswith("en"):
            string="endstat"
    elif string.startswith("q"):
        if len(string) == 1:
            string="quit"
    elif string.startswith("n"):
        if len(string) == 1:
            string="num"
    return string
