# ESDLang
basic programming language written in python

# Copyright/Licence
Copyright EyeScary Development (Wilbur Williams, Peter Rimmer and Jasper Cayley).

Public releases are licensed under the CC BY-SA 4.0 licence.
<https://creativecommons.org/licenses/by-sa/4.0/>
We reserve the right to change this licence for ANY FUTURE RELEASES of ESDLang.

Private development releases are NOT covered under ANY public licence.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.