# List of commands in editor
exit | x: close the file
run | rn: run the file (ESDLang only)
rewrite: (linenumber): Rewrites the given line
insert (linenumber): creates a new line before a given line number
delete (linenumber): deletes the line at a given line number