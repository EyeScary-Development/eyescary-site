print("python test")
print("hmmm")
# this will highlight print and input
# wheatley: "I am not a moron!"
# so basically python autocomplete is kinda useless cuz brackets
print("so autoreplacements are kinda useless")
