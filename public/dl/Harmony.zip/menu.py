#Harmony code editor menu 1.0
#Copyright EyeScary Development 2026
#Uses some code from Stronge by EyeScary Development

import editorcore
import os
import settings
def main():
    os.system("cls" if os.name == "nt" else "clear")
    print("Welcome to Harmony, the new text editor from EyeScary developent, would you like to:\n(e)dit a file\ngo to (s)ettings\nor (q)uit?")
    selection=input("| ")
    if selection=="e":
        os.system("cls" if os.name == "nt" else "clear")
        editorcore.main()
    elif selection=="s":
        os.system("cls" if os.name == "nt" else "clear")
        settings.main()
    else:
        quit()

if __name__ == "__main__":
    main()
