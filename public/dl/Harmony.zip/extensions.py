#Harmony code editor EXTENDED FUNCTIONS version 0.8
#Copyright EyeScary Development 2026
#Uses some code from Stronge by EyeScary Development

#Imports
import os
import langservhub
import runcode
from typing import (List, Any)
import tkinter # tkinter is used here to make editing a line compatible everywhere (clunkier but readline is only nix)
from pathlib import Path
from settings import checksetting
import term

#variables
root = tkinter.Tk()
root.withdraw()
runnable=[".esdla", ".py", ".java"]
#functions

def writeplus(self): #custom write function with autocorrect
        lines=langservhub.autocorrect(self.lines, self.filename)
        with open(self.filename, "w") as file:
            file.write(''.join(lines))

#prints out the file and judges wether syntax highlighing is needed
def printfile(extension, lines: List[Any], tofind=..., ):
    print(end="")
    langservhub.highlight(extension, lines, tofind) 

#calls the runcode file
def coderun(extension, filename):
    if extension in runnable:
        runcode.main(extension, filename)
    input("program finished, press enter to continue: ")

#deletes a line
def removeLine(linenum, lines):
    linenum=int(linenum)-1
    lines.pop(linenum)
    return lines

#replaces a line
def replaceLine(linenum, lines: List[Any]):
    linenum-=1
    root.clipboard_append(lines[linenum].strip("\n"))
    user_input = input("make edits to this line (current line is in your clipboard): ")
    lines[linenum]=user_input+'\n'
    return lines

#inserts a line
def insertLine(linenum, input_list: List[Any], lines: List[Any]):
    linenum-=1
    input_list.pop(0)
    lines.insert(linenum, ' '.join(input_list)+'\n')
    return lines

#replace function
def replace(input_list: List[Any], lines: List[Any]):
    torep=input_list[0]
    input_list.pop(0)
    for i in range(0, len(lines)-1):
        lines[i]=lines[i].strip("\n").replace(torep, ' '.join(input_list)) + "\n"
    return lines

#handles commands
def commands(userInput: str, lines: List[Any], filename, extension):
    command = userInput.split()[0]
    match command:
        case ":q" | ":x" | ":exit":
            os.system("cls" if os.name == "nt" else "clear")
            exit(0)
        case ":rm":
            lines = removeLine(userInput.split()[1], lines)
        case ":rw":
            listtoinput=userInput.split()
            listtoinput.pop(0)
            lines = replaceLine(int(listtoinput[0]), lines)
        case ':rp':
            listtoinput=userInput.split()
            listtoinput.pop(0)
            lines = replace(listtoinput, lines)
        case ":in":
            listtoinput=userInput.split()
            listtoinput.pop(0)
            lines = insertLine(int(listtoinput[0]), listtoinput, lines)
        case ":clf":
            lines=clearfile()
        case ":rn":
            coderun(extension, filename)
        case ":fnd":
            os.system("cls" if os.name == "nt" else "clear")
            printfile(extension, lines, userInput.split()[1])
            input('press enter to continue: ')
        case ":term":
            os.system("cls" if os.name == "nt" else "clear")
            term.main()
        case _:
            print("invalid command")
            input("press enter to continue: ")
    return lines


def clearfile():
    return []